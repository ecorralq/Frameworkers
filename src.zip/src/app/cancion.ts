export interface Cancion{
  id:number;
  titulo:string;
  autor:string;
  fecha:number;
  album:string;
  estilo:string;
}
